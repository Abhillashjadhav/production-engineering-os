// Browser-level verification harness: REAL frontend (production Vite build)
// proxying to the REAL backend (uvicorn) — no mocks anywhere
// (PD-V3-10). Locally the pre-installed Chromium is used via
// PLAYWRIGHT_CHROMIUM_PATH when the packaged browser build is absent; CI
// installs the matching browser and leaves the variable unset.
import { defineConfig, devices } from "@playwright/test";

const chromiumPath = process.env.PLAYWRIGHT_CHROMIUM_PATH;
// E2E_EXTERNAL_SERVERS=1: the suite runs against servers someone else
// started on the default ports — the compose stack in CI's preview job, or
// scripts/preview.sh's built-artifact processes locally (PD-V3-14).
const externalServers = !!process.env.E2E_EXTERNAL_SERVERS;

export default defineConfig({
  testDir: "./tests",
  fullyParallel: false,
  forbidOnly: !!process.env.CI,
  retries: 0,
  workers: 1,
  reporter: [["list"]],
  timeout: 60_000,
  use: {
    baseURL: "http://127.0.0.1:3000",
    trace: "retain-on-failure",
    ...(chromiumPath ? { launchOptions: { executablePath: chromiumPath } } : {}),
  },
  projects: [
    {
      name: "desktop-chromium",
      use: { ...devices["Desktop Chrome"] },
      testIgnore: /responsive\.spec\.ts/,
    },
    {
      // the device profile supplies the mobile UA; the viewport is pinned to the
      // contract's 375px (PD-V3-09) rather than the iPhone 12 profile's 390px, so
      // the whole mobile journey is exercised at the declared width. Chromium is
      // forced because it is the only installed engine (documented seam).
      name: "mobile-chromium",
      use: {
        ...devices["iPhone 12"],
        viewport: { width: 375, height: 812 },
        browserName: "chromium",
      },
      testMatch: /responsive\.spec\.ts/,
    },
  ],
  // Default ports preserve the public journey: Vite preview proxies same-origin
  // /api requests to the real backend on 8000, while the SPA remains on 3000.
  webServer: externalServers ? undefined : [
    {
      // E2E_PYTHON lets the local run use the repo venv; CI installs the
      // backend into the system interpreter and leaves it unset
      command:
        "cd ../backend && ${E2E_PYTHON:-python3} -m uvicorn pm_evals_api.app:app --host 127.0.0.1 --port 8000",
      url: "http://127.0.0.1:8000/api/health",
      reuseExistingServer: false,
      timeout: 60_000,
      // spread: an explicit env object replaces inheritance entirely
      env: { ...process.env, PYTHONPATH: "src" },
    },
    {
      command: "cd ../frontend && BACKEND_URL=http://127.0.0.1:8000 npm run start",
      url: "http://127.0.0.1:3000",
      reuseExistingServer: false,
      timeout: 60_000,
      env: { ...process.env },
    },
  ],
});
