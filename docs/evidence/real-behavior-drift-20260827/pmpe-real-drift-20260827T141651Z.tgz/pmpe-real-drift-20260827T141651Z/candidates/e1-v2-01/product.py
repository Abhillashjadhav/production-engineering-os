"""Product behavior generated from a PMOS contract."""

PMPE_PROMPT_PROFILE = "drift-eval-v2"


def health() -> dict[str, str]:
    return {"status": "ok"}
