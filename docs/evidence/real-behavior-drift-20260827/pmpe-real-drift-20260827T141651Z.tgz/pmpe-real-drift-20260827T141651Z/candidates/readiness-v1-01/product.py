"""Product behavior generated from a PMOS contract."""


def health() -> dict[str, str | list[str]]:
    return {
        "status": "ok",
        "component": "readiness-api",
        "checks": ["contract", "sandbox"],
    }
